This is version 2.5 of HornMorpho, a Python program that does morphological
analysis and generation of Amharic, Oromo, and Tigrinya words.
HornMorpho is part of the L3 Project
(http://www.cs.indiana.edu/~gasser/Research/projects.html).

To install HornMorpho, extract the files from the archive. Then go to
the directory HornMorpho-2.5 and do 

  python setup.py install

making sure that you are using Python 3, 3.1, or 3.2.

For information about using the program, see the manual or the quick
reference guide that came with the distribution: horn2.5.pdf, horn2.5_quick.pdf.
